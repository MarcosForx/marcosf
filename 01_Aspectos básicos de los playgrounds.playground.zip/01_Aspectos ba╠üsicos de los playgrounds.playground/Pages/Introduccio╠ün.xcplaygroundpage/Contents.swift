//: ## Aspectos básicos de los playgrounds
//: Bienvenido a tu primer playground. En este curso, usarás los playgrounds para aprender los aspectos básicos de la programación. Para comenzar, realizarás un recorrido breve y escribirás código.
//:
//: Antes de comenzar, ¿puedes ver los puntos animados a continuación?
//: Si no puedes verlos, ve a la barra de menú superior y selecciona Editor > Show Rendered Markup (Mostrar marcación terminada).
//:
//: ![puntos animados](swiftloading.gif)
//:
//: Si puedes ver los puntos animados, estás listo para comenzar.
//:
//:Página 1 de 7  |  [Siguiente: ¿Qué es un playground?](@next)
