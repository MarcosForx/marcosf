/*:
 ## Meme funcional
 
 Piensa en un meme o una canción divertidos que hayas visto o escuchado hace poco. Intenta pensar en un meme o una canción que tenga partes repetitivas. Por ejemplo:
 
 - Una canción en la que se repita el estribillo.
 - Un meme en el que se repita una palabra o frase.
 - Una canción en la que se repita varias veces una línea.
 
 Escribe la canción o el meme usando instrucciones `print`, después busca patrones y repeticiones, y selecciona grupos de líneas para combinarlas y así crear funciones. Este es un ejercicio libre, por lo que puedes hacer lo que desees.
*/


















//: A continuación, ponle tu sello personal al meme.
//:
//: [Anterior](@previous)  |  Página 11 de 12  |  [Siguiente: Meme personal](@next)
