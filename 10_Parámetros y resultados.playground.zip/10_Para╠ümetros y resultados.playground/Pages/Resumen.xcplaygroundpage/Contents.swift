/*:
 ## Resumen
 
 En esta lección, aprendiste a potenciar las funciones permitiéndoles tomar información, procesarla y devolver información.
 
 También aprendiste que las funciones deben leerse como oraciones cuando las llamas. Para eso, debes elegir con cuidado los nombres para tus parámetros y funciones.
 
 Al igual que todos los programas informáticos, las apps están diseñadas a partir de muchas funciones que envían y reciben información y procesan esos datos. Ahora, tienes las herramientas suficientes para crear estos componentes fundamentales.
 
 Resuelve los ejercicios para practicar lo que aprendiste.
 
[Anterior](@previous)  |  Página 13 de 17  |  [Siguiente: Ejercicio: Convertir sustantivos en verbos](@next)
*/
