/*:
 ## Resumen
 Te esforzaste mucho para darle un cerebro a QuestionBot y comprobaste lo útil que pueden ser los playgrounds para trabajar en funciones individuales sin distracciones.
 
 En la última parte de la lección, debes tomar la función nueva que creaste en la página anterior e incluirla en la app.
 
 Las instrucciones para hacerlo están en la Guía, en la lección “QuestionBot”.*/
/*:
 
 _Copyright © 2017 Apple Inc._
 
 _El presente documento otorga permiso, libre de cargos, a cualquier persona que obtenga una copia de este software y de los archivos de documentación asociados (el "Software") para utilizar el Software sin restricciones, incluidos, sin limitación, derechos para usar, copiar, modificar, combinar, publicar, distribuir, sublicenciar o vender copias del Software, y para permitir hacerlo a las personas a las que se proporcione el Software, siempre que se cumplan las siguientes condiciones:_
 
 _El anterior aviso de copyright y este aviso de permiso deben incluirse en todas las copias o partes importantes del Software._
 
 _EL SOFTWARE ES PROPORCIONADO “TAL COMO ESTÁ”, SIN GARANTÍA DE NINGÚN TIPO, YA SEA EXPRESA O IMPLÍCITA, INCLUIDAS, ENTRE OTRAS, LAS GARANTÍAS DE COMERCIABILIDAD, DE IDONEIDAD PARA UN FIN ESPECÍFICO O DE NO VIOLACIONES DE LOS DERECHOS DE AUTOR. EN NINGÚN CASO LOS AUTORES O LOS TITULARES DEL COPYRIGHT SERÁN RESPONSABLES DE RECLAMOS, DAÑOS Y PERJUICIOS U OTRAS RESPONSABILIDADES, YA SEA POR UNA ACCIÓN CONTRACTUAL, POR NEGLIGENCIA O POR OTROS MOTIVOS, QUE PUDIERAN SURGIR EN RELACIÓN CON EL SOFTWARE, SU UTILIZACIÓN U OTRAS OPERACIONES LLEVADAS A CABO CON ÉL._
 */
//:[Anterior](@previous)  |  Página 7 de 7
