import UIKit

let numberOfDogs = 6

let numberOfCats = 5

let numberOfTurtles = 2

let numberOfHamsters = 1

let 🐶 = 6
let 🐱 = 5
let 🐹 = 1
let 🐢 = 3
let 🐍 = 1
let 🐷 = 1
let 🐟 = 1

let nuumberofMammals = 🐶+🐷+🐹+🐱
let totalNumberOfAnimals = 🐶 + 🐱 + 🐹 + 🐢 + 🐍 + 🐷 + 🐟
///------------------------------------------------------------------------------------------

var NumberOfTickets = 150

let TicketPrice = 10

let RoomRentalFee = 50

let PosterCost = 40

var TotalTicketValue = 0

var TotalExpenses = 0
var TotalIncomeOfShow = 0


TotalExpenses = TicketPrice+RoomRentalFee+PosterCost

TotalTicketValue =  NumberOfTickets*TicketPrice

TotalIncomeOfShow = TotalTicketValue + TotalExpenses

///------------------------------------------------------------------------------------------

let ticketsSold = 1000
let ticketPrice = 1
let printingCosts = 20
let advertising = 50




